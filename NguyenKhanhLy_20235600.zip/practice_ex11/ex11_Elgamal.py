import json
import sys
from pathlib import Path
from math import gcd

def modinv(a, m):
    a %= m
    try:
        return pow(a, -1, m)
    except TypeError:
        # extended gcd fallback
        a0, m0 = a, m
        x0, x1 = 1, 0
        while m0:
            q = a0 // m0
            a0, m0, x0, x1 = m0, a0 - q * m0, x1, x0 - q * x1
        if a0 != 1:
            raise ValueError("Inverse does not exist")
        return x0 % m

def solve_2x2_mod(q, s1, r1, s2, r2, x1, x2):
    a = s1 % q; b = r1 % q
    c = s2 % q; d = r2 % q
    det = (a * d - b * c) % q
    if gcd(det, q) != 1:
        raise ValueError(f"Determinant not invertible mod q (det={det}).")
    inv_det = modinv(det, q)
    rhs1 = x1 % q
    rhs2 = (x2 - s2) % q
    k1 = ( (rhs1 * d - b * rhs2) * inv_det ) % q
    dd = ( (-rhs1 * c + a * rhs2) * inv_det ) % q
    return k1, dd, det, inv_det

def verify_signature(p, q, g, sig1, k1, d):
    x1, r1, s1 = sig1['x'], sig1['r'], sig1['s']
    r_calc = pow(g, k1, p)
    ok_r = (r_calc % p) == (r1 % p)
    if gcd(k1, q) != 1:
        ok_s = False
        s_calc = None
    else:
        s_calc = (modinv(k1, q) * ((x1 - d * (r1 % q)) % q)) % q
        ok_s = (s_calc % q) == (s1 % q)
    return ok_r, ok_s, r_calc % p, s_calc

def process(params, label, shared_output_file="private.txt"):
    p = int(params['p']); q = int(params['q']); g = int(params['g'])
    sig1 = {k:int(v) for k,v in params['sig1'].items()}
    sig2 = {k:int(v) for k,v in params['sig2'].items()}

    try:
        k1, d, det, inv_det = solve_2x2_mod(q,
                                          sig1['s'], sig1['r'],
                                          sig2['s'], sig2['r'],
                                          sig1['x'], sig2['x'])
    except Exception as e:
        print(f"[{label}] Could not solve 2x2 system: {e}")
        return None

    with open(shared_output_file, "a") as f:
        f.write(f"=== {label} ===\n")
        f.write(f"Recovered private key d = {d}\n\n")

    ok_r, ok_s, r_calc, s_calc = verify_signature(p, q, g, sig1, k1, d)
    
    if ok_r and ok_s:
        print(f"[{label}] Success! Recovered d: {d}")
    else:
        print(f"[{label}] Warning: Verification failed. Recovered d: {d}")

    return d


if __name__ == "__main__":
    # Built-in datasets (Level1 from practiceEx11.docx, Level2 from assignment)
    LEVEL_1 = {
        "p": 467, "q": 233, "g": 225, "y": 252,
        "sig1": {"x": 151, "r": 47, "s": 94},
        "sig2": {"x": 46, "r": 301, "s": 133},
        "expected": 21
    }
    LEVEL_2 = {
        "p": 21617692091972978742235166480742862532407156107636789231276846348871806805459265097334588112742408477197337174109396234828782656654798240250161457460539107,
        "q": 10808846045986489371117583240371431266203578053818394615638423174435903402729632548667294056371204238598668587054698117414391328327399120125080728730269553,
        "g": 8143651548100947843382350751344608024514508427736080091651634668538984233972621950778992546927258791789679928270857984915727688029043622808767719120145074,
        "y": 5337741482750797476261738705281015195709371216778881633606734128234762113049696886434515870887750677662738177268317668593170743480677686307821740168619786,
        "sig1": {
            "x": 700495879643683054817375080824786066232130521319731986884895012040965686006464788788827750493322383874538420521981138868303353190260424143057326776757373,
            "r": 21442891835433236617485085355436041175289688399925396587145558330757037993993280456584809628106791530886244611686592667399267838111887731372657587978697768,
            "s": 9578212581237917941432747084881128196179354508788807162140588617803641561276876172329278898846222343300996748745568300211454084744121492123145984865114214
        },
        "sig2": {
            "x": 7948944228808646192883566297506348894200221948529547265350717153384406128671428403594981779545621945879049610232293959849646101244254283491779346594596773,
            "r": 14237018484274987810297519540781222437887587222087300824402427487699647704800632115982276060742478686125469062670076006247438209565913707179757512193326796,
            "s": 10622307882903918298403370294837054194996446050344436880766181995133143646783877563956424755967519418900317082840363586379948106787342394514047484044936934
        }
    }

    process(LEVEL_1, "Level_1", "private.txt")
    process(LEVEL_2, "Level_2", "private.txt")